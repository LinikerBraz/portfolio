Hello!

Thanks for download and use our font.

Noxlock free for personal use.

you can buy it from:
https://creativemarket.com/sentype/42323320-Noxlock-Rounded-Sans-Serif

or please contact me: 
sentype.studio@gmail.com

---------------------

Designed by Saidi Alfianor
Copyright (c) 2023 by Sentype Foundry. All rights reserved.